# MyReads Project


## Instructions to get starting


* install all project dependencies with `npm install`
* start the development server with `npm start`

## The app funcionality

this app allows you to put the book you are interested in reading in three shleves which are (currently reading,want to read,read) and allows you to to move books between shelves so you can see anytime you want and search for a new books to add for your list



